<?php

include 'header.php';
include("cart.php");
include("config.inc.php"); //include config file
?>
<style type="text/css">

h1.page-header {
    font-size: 26px;
    color: #000000;
}
h4.page-header {
    font-size: 16px;
    color: #FFF;
}
.thumbnail .caption-full
{
    padding: 9px;
    color: #333;
}
.avatar-xs {
    border-radius: 100%;
    height: 25px;
    width: 25px;
}
</style>


<section id="main-slider" class="no-margin">
     <h1 class="page-header"><img src="images/services/services1.png" class="avatar-xs"> RECENT NEWS </h1>
    <?php

    $x=0;
    $sql = "SELECT * FROM news ORDER BY likes DESC LIMIT 4";
    $result = mysqli_query($mysqli_conn , $sql);
    while($row = mysqli_fetch_array($result))
    {
                

            ?>
    <div class="mySlides">
        <div class="carousel slide">
            <div class="item active" style="background-image: url(images/slider/bg3.jpg)">
                <div class="container">
                
                    <div class="row slide-margin">
                        <div class="col-sm-6">
                            <div class="carousel-content">
                                <h1 class="animation animated-item-1"><?php echo $row['headline']; ?></h1>
                                <h4 class="page-header"><?php echo $row['description']; ?></h4>
                                <a class="btn-slide animation animated-item-3" href="newsdetails.php">Read More</a>
                            </div>
                        </div>

                        <div class="col-sm-6 hidden-xs animation animated-item-4">
                            <div class="slider-img">
                                <img src="images/news/<?php echo $row['newspicture']; ?>" class="img-responsive" alt="Cinque Terre" width="500" height="550">
                            </div>
                        </div>

                    </div>
                </div>
            </div><!--/.item-->

        </div><!--/.carousel-inner-->
    </div><!--/.carousel-->
     <?php
     
    }

     ?>
     <a class="prev hidden-xs" href="#main-slider" data-slide="prev" onclick="plusDivs(-1)">
        <i class="fa fa-chevron-left">
            
        </i>
    </a>
    <a class="next hidden-xs" href="#main-slider" data-slide="next" onclick="plusDivs(1)">
        <i class="fa fa-chevron-right">
        </i>
    </a>
                
</section><!--/#main-slider-->





<section id="main-slider" class="no-margin">
     <h1 class="page-header"><img src="images/services/services1.png" class="avatar-xs"> New Arrival Products </h1>
    <?php

    $x=0;
    $sql = "SELECT * FROM products_list Order BY id DESC LIMIT 5";
    $result = mysqli_query($mysqli_conn , $sql);
    while($row = mysqli_fetch_array($result))
    {
                

            ?>
    <div class="mySlides1">
        <div class="carousel slide">
            <div class="item active" style="background-image: url(images/slider/bg3.jpg)">
                <div class="container">
                
                    <div class="row slide-margin">
                        <div class="col-sm-6">
                            <div class="carousel-content">
                                <h1 class="animation animated-item-1"><?php echo $row['product_name']; ?></h1>

                                <a class="btn-slide animation animated-item-3" href="newsdetails.php">Read More</a>
                            </div>
                        </div>

                        <div class="col-sm-6 hidden-xs animation animated-item-4">
                            <div class="slider-img">
                                <img src="images/<?php echo $row['product_image']; ?>" class="img-responsive" alt="Cinque Terre" width="500" height="550">
                            </div>
                        </div>

                    </div>
                </div>
            </div><!--/.item-->

        </div><!--/.carousel-inner-->
    </div><!--/.carousel-->
     <?php
     
    }

     ?>
     <a class="prev hidden-xs" href="#main-slider" data-slide="prev" onclick="plusDivs1(-1)">
        <i class="fa fa-chevron-left">
            
        </i>
    </a>
    <a class="next hidden-xs" href="#main-slider" data-slide="next" onclick="plusDivs1(1)">
        <i class="fa fa-chevron-right">
        </i>
    </a>
                
</section><!--/#main-slider-->



    </div>


<?php 
include("footer.php");

?>
<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}
</script>
<script>
var slideIndex1 = 1;
showDivs(slideIndex1);

function plusDivs1(n) {
  showDivs(slideIndex1 += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides1");
  if (n > x.length) {slideIndex1 = 1}    
  if (n < 1) {slideIndex1 = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex1-1].style.display = "block";  
}
</script>
<?php require_once 'header.php';?>
<?php
require_once "config.inc.php"; //include config file
?>
<div class="grey">
	<div class="container">
		<div class="btn-group-vertical" role="group" aria-label="btn">
	  	<a href="admin.php"><button type="submit" name="Insert" class="btn btn-primary">Insert product</button></a>
	  	<a href="insertvideo.php"><button type="submit" name="Insert" class="btn btn-primary">Insert Video</button></a>
	  	<a href="update.php"><button type="submit" name="Insert" class="btn btn-primary">Update</button></a>
	  	<a href="delete.php"><button type="submit" name="Insert" class="btn btn-primary">Delete</button></a>
		</div>
	</div>
</div>






<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Please login to buy your product</title>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">
	        
</head>
<body>
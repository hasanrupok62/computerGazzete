<?php
?>
<!--<div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModal" aria-hidden="true"  >
                <div class="modal-dialog modal-lg" >
                    <div class="modal-content" >
                        <div class="modal-body" >
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <div class="">
                                  <iframe class="embed-responsive-item" src="" ></iframe>
                                </div>
                        </div>
                    </div>
                </div>
            </div>-->
<div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModal" aria-hidden="true">
                <div class="modal-dialog modal-lg" style="width:1080px;">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <div class="embed-responsive embed-responsive-16by9">
                                  <iframe class="embed-responsive-item" src=""></iframe>
                                </div>
                        </div>
                    </div>
                </div>
            </div>

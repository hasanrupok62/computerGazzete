  <!DOCTYPE html>
<html lang="en">
<head>
 <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
  <link href="login.css" rel="stylesheet">
  </head>
<div class="container">
  <!-- Trigger the modal with a button -->


  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sign Up Now</h4>
        </div>
        <div class="modal-body">

          

    <div class="container-fluid">
   <form action="" method="" class="register-form"> 
      <div class="row">      
           <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
              <label for="firstName">NAME</label>
               <input name="firstName" class="form-control" type="text">    
           </div>            
      </div>
      <div class="row">      
           <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
              <label for="firstName">USER NAME</label>
               <input name="firstName" class="form-control" type="text">    
           </div>            
      </div>
      <div class="row">
           <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
              <label for="email">EMAIL</label>
               <input name="email" class="form-control" type="email">             
           </div>            
      </div>

        <div class="row">
           <div class="col-md-6 col-sm-6 col-xs-6 col-lg-6">
               <label for="password">PASSWORD</label>
               <input name="password" class="form-control" type="password">

          </div>
          <div class="col-md-6 col-sm-6 col-xs-6 col-lg-6">
          <img src="images/gmail.jpg" alt="Mountain View" style="width:250px;height:80px;">           
          </div>          
      </div>

      <div class="row">
           <div class="col-md-6 col-sm-6 col-xs-6 col-lg-6">
              <label for="password">CONFIRM PASSWORD</label>
               <input name="password" class="form-control" type="password">

          </div>
          <div class="col-md-6 col-sm-6 col-xs-6 col-lg-6">
          <img src="images/facebook.jpg" alt="Mountain View" style="width:250px;height:80px;">           
          </div>          
      </div> 
      <hr>
      <div class="row">
           <div class="col-md-6 col-sm-6 col-xs-6 col-lg-6">
           
           <a href="#">Forgot Password</a>

          </div>
          <div class="col-md-3 col-sm-3 col-xs-3 col-lg-3">
           <button class="btn btn-default logbutton">Sign up</button>           
          </div>  

          <div class="col-md-3 col-sm-3 col-xs-3 col-lg-3">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div> 


      </div> 

  
    </form>
  </div>
    

      
    </div>
  </div>
  
</div>
</body>
</html>